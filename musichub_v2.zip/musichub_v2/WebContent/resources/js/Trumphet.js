/**
 * 
 */
/**
 * 
 */
// Define a new module for our app
var app = angular.module("instantSearch", []);

// Create the instant search filter

app.filter('searchFor', function(){

	// All filters must return a function. The first parameter
	// is the data that is to be filtered, and the second is an
	// argument that may be passed with a colon (searchFor:searchString)

	return function(arr, searchString){

		if(!searchString){
			return arr;
		}

		var result = [];

		searchString = searchString.toLowerCase();

		// Using the forEach helper method to loop through the array
		angular.forEach(arr, function(item){

			if(item.title.toLowerCase().indexOf(searchString) !== -1){
				result.push(item);
			}

		});

		return result;
	};

});

// The controller

function InstantSearchController($scope){

	// The data model. These items would normally be requested via AJAX,
	// but are hardcoded here for simplicity. See the next example for
	// tips on using AJAX.

	$scope.items = [

		{
			url: '',
			title: 'Trumphet',
			image: 'resources/images/1.jpg'
		},
		{
			url: '',
			title: 'Trumphet Brass',
			image: 'resources/images/1t.jpg'
		},
		{
			url: '',
			title: 'Trumphet 567ss',
			image: 'resources/images/2t.jpg'
		},{
			url: '',
			title: 'Trumphet alcordas 340',
			image: 'resources/images/3t.jpg'
		},
		{
			url: '',
			title: 'Trumphet stlyus',
			image: 'resources/images/4t.JPG'
		},
		{
			url: '',
			title: 'Trumphet 456',
			image: 'resources/images/5t.jpg'
		}
		
	];


}
