// Define a new module for our app
var app = angular.module("instantSearch", []);

// Create the instant search filter

app.filter('searchFor', function(){

	// All filters must return a function. The first parameter
	// is the data that is to be filtered, and the second is an
	// argument that may be passed with a colon (searchFor:searchString)

	return function(arr, searchString){

		if(!searchString){
			return arr;
		}

		var result = [];

		searchString = searchString.toLowerCase();

		// Using the forEach helper method to loop through the array
		angular.forEach(arr, function(item){

			if(item.title.toLowerCase().indexOf(searchString) !== -1){
				result.push(item);
			}

		});

		return result;
	};

});

// The controller

function InstantSearchController($scope){

	// The data model. These items would normally be requested via AJAX,
	// but are hardcoded here for simplicity. See the next example for
	// tips on using AJAX.

	$scope.items = [
		{
			url: '',
			title: 'Trumphet',
			image: 'resources/images/1.jpg'
		},
		{
			url: '',
			title: 'Trumphet Brass',
			image: 'resources/images/1t.jpg'
		},
		{
			url: '',
			title: 'Trumphet 567ss',
			image: 'resources/images/2t.jpg'
		},{
			url: '',
			title: 'Trumphet alcordas 340',
			image: 'resources/images/3t.jpg'
		},
		{
			url: '',
			title: 'Trumphet stlyus',
			image: 'resources/images/4t.JPG'
		},
		{
			url: '',
			title: 'Trumphet 456',
			image: 'resources/images/5t.jpg'
		},
		
		{
			url: '',
			title: 'Sitar',
			image: 'resources/images/2.jpg'
		},
		{
			url: '',
			title: 'yamaha 560s sitar',
			image: 'resources/images/1s.jpg'
		},
		{
			url: '',
			title: 'imported 56gh7 sitar',
			image: 'resources/images/2s.jpg'
		},
		{
			url: '',
			title: 'Coverto caloso sitar',
			image: 'resources/images/3s.JPG'
		},
		{
			url: '',
			title: 'blazzy sitar',
			image: 'resources/images/4s.jpg'
		},
		{
			url: '',
			title: 'kanchi sitar',
			image: 'resources/images/5s.jpg'
		},
		{
			url: '',
			title: 'Alkimo Thambura ',
			image: 'resources/images/3.gif'
		},
		{
			url: '',
			title: 'AGHA Thambura',
			image: 'resources/images/1th.jpg'
		},
		{
			url: '',
			title: 'Celebrio Thambura',
			image: 'resources/images/2th.jpg'
		},
		{
			url: '',
			title: 'hgj67 Thanmbura',
			image: 'resources/images/3th.JPG'
		},
		{
			url: '',
			title: 'heleroi Thambura',
			image: 'resources/images/4th.JPG'
		},
		{
			url: '',
			title: 'Kanchi Thambura',
			image: 'resources/images/5th.jpg'
		},
		{
			url: '',
			title: 'Fantascio guitar',
			image: 'resources/images/1g.jpg'
		},
		{
			url: '',
			title: 'K&J guitar',
			image: 'resources/images/2g.jpg'
		},
		{
			url: '',
			title: 'Blazal guitar',
			image: 'resources/images/3g.jpg'
		},
		{
			url: '',
			title: 'Colomsky Guitar',
			image: 'resources/images/4g.jpg'
		},
		{
			url: '',
			title: 'VV Guitar',
			image: 'resources/images/5g.jpg'
		},
		{
			url: '',
			title: 'Guitar',
			image: 'resources/images/4.jpg'
		}
		
	];


}
