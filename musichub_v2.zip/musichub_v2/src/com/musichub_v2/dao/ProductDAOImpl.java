package com.musichub_v2.dao;

import java.util.ArrayList;
import java.util.List;

import com.musichub_v2.model.Product;

public class ProductDAOImpl implements ProductDAO {
	List<Product> al=new ArrayList<Product>();
	

	public List<Product> getAl() {
		return al;
	}

	public void setAl(List<Product> al) {
		this.al = al;
	}

	@Override
	public void add(Product p) {
		// TODO Auto-generated method stub

	}

	@Override
	public void update(Product p) {
		// TODO Auto-generated method stub

	}

	@Override
	public void delete(Product p) {
		// TODO Auto-generated method stub

	}

	@Override
	public void select(Product p) {
		// TODO Auto-generated method stub

	}

	public ProductDAOImpl() {
		
		al.add(new Product("Trumphet","P100","http://localhost:8080/musichub/allproducts.jsp?fileurl=resources%2Fimages%2F1.jpg&productname=Trumphet&productid=P100","resources/images/1.jpg"));
		al.add(new Product("Trumphet Brass","P101","http://localhost:8080/musichub/allproducts.jsp?fileurl=resources%2Fimages%2F1t.jpg&productname=Trumphet+Brass&productid=P101","resources/images/1t.jpg"));
		al.add(new Product("Trumphet 567ss","P102","http://localhost:8080/musichub/allproducts.jsp?fileurl=resources%2Fimages%2F2t.jpg&productname=Trumphet+567ss&productid=P102","resources/images/2t.jpg"));
		al.add(new Product("Trumphet alcordas 340","P103","http://localhost:8080/musichub/allproducts.jsp?fileurl=resources%2Fimages%2F3t.jpg&productname=Trumphet+alcordas+340&productid=P103","resources/images/3t.jpg"));
		al.add(new Product("Trumphet stlyus","P104","http://localhost:8080/musichub/allproducts.jsp?fileurl=resources%2Fimages%2F4t.JPG&productname=Trumphet+stlyus&productid=P104","resources/images/4t.JPG"));
		al.add(new Product("Trumphet 456","P105","http://localhost:8080/musichub/allproducts.jsp?fileurl=resources%2Fimages%2F5t.jpg&productname=Trumphet+456&productid=P105","resources/images/5t.jpg"));
		al.add(new Product("Sitar","P106","http://localhost:8080/musichub/allproducts.jsp?fileurl=resources%2Fimages%2F2.jpg&productname=Sitar&productid=P106","resources/images/2.jpg"));
		al.add(new Product("yamaha 560s sitar","P106","http://localhost:8080/musichub/allproducts.jsp?fileurl=resources%2Fimages%2F2s.jpg&productname=yamaha+560s+sitar&productid=P107","resources/images/2s.jpg"));
		al.add(new Product("imported 56gh7 sitar","P106","http://localhost:8080/musichub/allproducts.jsp?fileurl=resources%2Fimages%2F3s.JPG&productname=yamaha+560s+sitar&productid=P108","resources/images/3s.JPG"));
		
		
		
		
	}
	

}
