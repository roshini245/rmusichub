package com.musichub_v2.dao;

import com.musichub_v2.model.Product;

public interface ProductDAO {
public void add(Product p);
public void update(Product p);
public void delete(Product p);
public void select(Product p);

}
