package com.musichub_v2.controller;
import java.io.File;

import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.servlet.ModelAndView;

import com.musichub_v2.dao.ProductDAOi;
import com.musichub_v2.dao.ProductDAOImpl;
 

 
@Controller
public class dispatcher {
 
	@RequestMapping("/welcome")
	public ModelAndView helloWorld() {
 
		String message = "<br><div style='text-align:center;'>"
				+ "<h3>********** Hello World, Spring MVC Tutorial</h3>This message is coming from CrunchifyHelloWorld.java **********</div><br><br>";
		return new ModelAndView("welcome", "message", message);
	}
	@RequestMapping("/Product.jsp")
	   public String redirect() {
	     try{
	    	 ObjectMapper mapper = new ObjectMapper();
	    	 ProductDAOImpl p=new ProductDAOImpl();

	    	 //Object to JSON in file
	    	 mapper.writeValue(new File("D:\\musichub\\musichub_v2\\WebContent\\resources\\js\\sample.json"), p.getAl());

	    	 //Object to JSON in String
	    	 String jsonInString = mapper.writeValueAsString(p.getAl());
	    	 System.out.println(jsonInString);
	     }
	     catch(Exception e){
	    	 
	     }
	      return "Product";
	   }
	@RequestMapping("/allproducts.jsp")
	   public String redirectallproducts() {
	     
	      return "allproducts";
	   }
	}
