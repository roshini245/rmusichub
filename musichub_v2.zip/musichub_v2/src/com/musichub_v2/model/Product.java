package com.musichub_v2.model;

public class Product {
	String name;
	String id;
	String url;
	public Product(String name, String id, String url, String image) {
		super();
		this.name = name;
		this.id = id;
		this.url = url;
		this.image = image;
	}
	String image;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}

}
